int main(){
int a=10;
int b=0x12;
int c=017;
int d=0x1z;
int e=08;
~
return 0;
int a[]={1};
}
